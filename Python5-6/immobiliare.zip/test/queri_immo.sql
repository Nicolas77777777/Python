-- genera filiale

INSERT INTO filiali (partita_iva, nome, indirizzo_sede, civico, telefono)
VALUES 
('1', 'Filiale Centro', 'Via Roma', 10, '1234567890');

INSERT INTO filiali (partita_iva, nome, indirizzo_sede, civico, telefono)
VALUES 
('2', 'Filiale Nord', 'Corso Italia', 25, '0987654321');